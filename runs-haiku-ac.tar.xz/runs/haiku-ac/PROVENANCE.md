# Haiku A vs C replication (item 10)

Copied from runs/haiku/{chat_only,rule_graph} on 2026-10-25, then resumed to 40 games each.

- chat_only seeds 0-9 and rule_graph seeds 0-13 were played at 486bac6 (merlin-vote-cover branch,
  merlin_strategy: default). manifest.json still names that commit because resume keeps the manifest.
- All later seeds were played on branch cleanup at 616aa3e.
- For non-Percival games the agent prompts and logic are the same at both commits (the diff is Percival,
  Morgana, merlin_strategy and the removed voice layer).
